#include "favorite.h"

Favorite::Favorite()
{

}

Favorite::Favorite(QString name, QUrl url) {

}
