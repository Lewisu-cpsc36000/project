#include "qtabbar.h"

QTabBar::QTabBar()
{

}
