#ifndef QTABBAR_H
#define QTABBAR_H


class QTabBar
{
public:
    QTabBar();
};

#endif // QTABBAR_H
